package uz.hov

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var cb: ValueCallback<Array<Uri>>? = null

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)

        if (Build.VERSION.SDK_INT >= 34 &&
            !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        ) startActivity(
            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
        )

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView?, c: ValueCallback<Array<Uri>>?, p: WebChromeClient.FileChooserParams?
            ): Boolean {
                cb?.onReceiveValue(null)
                cb = c
                return try {
                    startActivityForResult(p!!.createIntent(), 1)
                    true
                } catch (e: Exception) {
                    cb = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 1) {
            cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d))
            cb = null
        } else super.onActivityResult(r, c, d)
    }

    inner class Bridge {
        @JavascriptInterface
        fun schedule(id: Int, at: String, title: String, text: String) {
            Sched.set(this@MainActivity, id, at.toLong(), title, text)
        }

        @JavascriptInterface
        fun cancel(id: Int) {
            Sched.cancel(this@MainActivity, id)
        }

        @JavascriptInterface
        fun startAlarm() {
            startForegroundService(Intent(this@MainActivity, AlarmService::class.java))
        }

        @JavascriptInterface
        fun stopAlarm() {
            stopService(Intent(this@MainActivity, AlarmService::class.java))
        }
    }
}
